<?php

namespace App\Form;

use App\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RegisterType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('Name',TextType::class,[ 
            'attr' => [ 
                'placeholder' => 'Merci de saisir votre nom'
            ]])

            ->add('email',EmailType::class, [
                'label' => 'Votre mail',

                'attr' => [
                    'placeholder' => 'Merci de saisir votre mail'
                ]
            ])

            ->add('password',RepeatedType::class, [
                'type' => PasswordType::class,
                'invalid_message' => 'Le mot de passe et la confirmation doivent être unique',
                'required' =>true,
                 
                'first_options' => [
                'label' => 'Votre mot de passe',
                'attr' => [
                    'placeholder' => 'Merci de saisir votre mot de passe'
                ]
                
                ],
                'second_options' => [
                'label' => 'Confirmer votre mot de passe',
                'attr' => [
                    'placeholder' => 'Merci de confirmer votre mot de passe'
                ]
                ]
            ])

            ->add('Company',TextType::class,[ 
                'attr' => [ 
                    'placeholder' => 'Merci de saisir votre entreprise'
                ]])
            ->add('Telephone',NumberType::class,[ 
                'attr' => [ 
                    'placeholder' => 'Merci de saisir votre Télephone'
                ]])
            ->add('submit',SubmitType::class, [
                'label' => "S'inscrire",])
        
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => User::class,
        ]);
    }
}
