<?php

namespace App\Controller;
use App\Entity\Card;
use App\Form\RegisterType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;



class AjoutCardController extends AbstractController
{
    private $entityManager;
    public function __construct(EntityManagerInterface $entityManager){
        $this->entityManager = $entityManager;
    }

    #[Route('/compte/ajout_card', name: 'ajout_card')]
    public function  index(Request $request)
    {
        $card = new Card();
        $form = $this->createForm(RegisterType::class,$card);
        $form -> handleRequest($request);
        if ($form->isSubmitted() && $form -> isValid()){
        $card = $form->getData();
        $this->entityManager->persist($card);
        $this->entityManager->flush();
        }

        return $this->render('account/Card.html.twig',[

            'form' => $form->createView()

        ]);
    }

    public function article($name){
        // On récupère l'article correspondant au slug
        $card = $this->getDoctrine()->getRepository(Articles::class)->findOneBy(['name' => $name]);
        if(!$card){
            // Si aucun article n'est trouvé, nous créons une exception
            throw $this->createNotFoundException('La carte n\'existe pas');
        }
        // Si l'article existe nous envoyons les données à la vue
        return $this->render('articles/article.html.twig', compact('card'));
    }
    
    
}
