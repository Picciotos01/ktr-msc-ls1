<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_91d58e248aa170966c4c951894782956 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo " <section class=\"py-5 text-center container\">
    <div class=\"row py-lg-5\">
      <div class=\"col-lg-6 col-md-8 mx-auto\">
        <h1 class=\"fw-light\">Library for card</h1>
        <p class=\"lead text-muted\">C'est une bibliothèque des cartes</p>
      </div>
    </div>
  </section>

  <div class=\"album py-5 bg-light\">
    <div class=\"container\">

      <div class=\"row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3\">
        <div class=\"col\">
          <div class=\"card shadow-sm\">
            <div class=\"card-body\">
              <p class=\"card-text\">Ma carte</p>
              <div class=\"d-flex justify-content-between align-items-center\">
                <div class=\"btn-group\">
                  <button type=\"button\" class=\"btn btn-sm btn-outline-secondary\">Voire</button>
                </div>
              </div>
            </div>
          </div>
        </div>





        <div class=\"col\">
          <div class=\"card shadow-sm\">

            <div class=\"card-body\">
              <p class=\"card-text\">Ma carte</p>
              <div class=\"d-flex justify-content-between align-items-center\">
                <div class=\"btn-group\">
                  <button type=\"button\" class=\"btn btn-sm btn-outline-secondary\">Voire</button>

                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

 {% block content %}
 <section class=\"py-5 text-center container\">
    <div class=\"row py-lg-5\">
      <div class=\"col-lg-6 col-md-8 mx-auto\">
        <h1 class=\"fw-light\">Library for card</h1>
        <p class=\"lead text-muted\">C'est une bibliothèque des cartes</p>
      </div>
    </div>
  </section>

  <div class=\"album py-5 bg-light\">
    <div class=\"container\">

      <div class=\"row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3\">
        <div class=\"col\">
          <div class=\"card shadow-sm\">
            <div class=\"card-body\">
              <p class=\"card-text\">Ma carte</p>
              <div class=\"d-flex justify-content-between align-items-center\">
                <div class=\"btn-group\">
                  <button type=\"button\" class=\"btn btn-sm btn-outline-secondary\">Voire</button>
                </div>
              </div>
            </div>
          </div>
        </div>





        <div class=\"col\">
          <div class=\"card shadow-sm\">

            <div class=\"card-body\">
              <p class=\"card-text\">Ma carte</p>
              <div class=\"d-flex justify-content-between align-items-center\">
                <div class=\"btn-group\">
                  <button type=\"button\" class=\"btn btn-sm btn-outline-secondary\">Voire</button>

                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 {% endblock %}
", "home/index.html.twig", "/Users/salaheddinehoukmi/Desktop/epitech/epitechProject/templates/home/index.html.twig");
    }
}
